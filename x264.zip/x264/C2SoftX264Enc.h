#pragma once

#include <C2Component.h>
#include <C2.h>
#include <C2Buffer.h>
#include <SimpleC2Component.h>

class C2SoftX264Enc : public android::SimpleC2Component {
public:
    C2SoftX264Enc(const char* name, c2_node_id_t id, const std::shared_ptr<C2ComponentInterface>& interface);
    ~C2SoftX264Enc() override;
    c2_status_t onInit() override;
    void process(
        const std::unique_ptr<C2Work>& work,
        const std::shared_ptr<C2BlockPool>& pool) override;
};

