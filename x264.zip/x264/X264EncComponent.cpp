#include "C2SoftX264Enc.h"

class C2SoftX264EncFactory : public C2ComponentFactory {
public:
    C2SoftX264EncFactory() = default;
    ~C2SoftX264EncFactory() override = default;

    c2_status_t createComponent(
        c2_node_id_t id,
        std::shared_ptr<C2Component>* const component,
        std::function<void(C2Component*)> deleter) override {
        *component = std::shared_ptr<C2Component>(
            new C2SoftX264Enc("C2SoftX264Enc", id, createInterface()),
            deleter);
        return C2_OK;
    }

    std::shared_ptr<C2ComponentInterface> createInterface() {
        // Describe encoder parameters
        return nullptr;
    }
};

extern "C" ::android::hardware::media::c2::V1_0::utils::ComponentFactory*
CreateCodec2Factory() {
    return new C2SoftX264EncFactory();
}

